---
description: Quality standards for scripts in .agent/scripts/, focusing on Python
---

# Script Quality Standards

## Overview
This document defines quality standards for scripts in `.agent/scripts/`, ensuring maintainability, readability, and reliability. Based on `.agent/rules/development/code-quality.md`.

## Language and Tools
- **Primary Language**: Python 3.8+ (minimal dependencies)
- **Linter**: Ruff (fast, comprehensive Python linter)
- **Formatter**: Black (opinionated code formatter)
- **Type Checker**: MyPy (static type analysis)
- **Language Server**: Pylance (IDE support for diagnostics)

## Coding Standards
### Readability
- Use clear variable names (e.g., `human_name` instead of `h`)
- Add docstrings for functions and classes
- Limit line length to 88 characters (Black default)
- Use consistent indentation (4 spaces)

### Error Handling
- Handle potential exceptions (e.g., file I/O errors, directory creation)
- Use try-except blocks with specific exceptions
- Log errors appropriately (print to stderr or use logging module)

### Type Hints
- Add type hints to all function parameters and return types
- Use `Optional` for nullable types
- Run MyPy checks before committing

### Dependencies
- Minimize external dependencies; prefer standard library
- List all dependencies in `requirements.txt` or `pyproject.toml`
- Specify version pins for reproducibility

## Development Workflow
1. **Write Code**: Follow standards from initial draft
2. **Format**: Run Black formatter
3. **Lint**: Run Ruff for style and error checks
4. **Type Check**: Run MyPy for type safety
5. **Test**: Write unit tests if complexity warrants (use pytest)
6. **Commit**: Only after passing all checks

## Example for log_conversation.py
- **Structure**: Function-based, no classes unless needed
- **Imports**: Only necessary modules (e.g., `os`, `datetime`)
- **Testing**: Simple unit test for file creation and format

## Exceptions
- If script is a one-off or prototype, standards can be relaxed with user approval
- For non-Python scripts, adapt tools accordingly (e.g., ESLint for JS)

---
*Reference: `.agent/rules/development/code-quality.md`*
